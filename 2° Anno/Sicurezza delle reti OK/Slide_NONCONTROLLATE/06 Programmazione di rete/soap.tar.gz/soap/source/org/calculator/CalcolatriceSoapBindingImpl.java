package org.calculator; 

public class CalcolatriceSoapBindingImpl implements org.calculator.Calcolatrice{ 
    public java.lang.String calcola(String operazione, Double x, Double y) throws java.rmi.RemoteException { 

	Double risultato = 0.0;
	String simbolo = "";	

	if (operazione.equalsIgnoreCase("somma"))
	{
	  risultato = x+y;
	  simbolo = "+";
	}
	else if (operazione.equalsIgnoreCase("sottrazione"))
	{
	  risultato = x-y;
	  simbolo = "-";  
	}
	else if (operazione.equalsIgnoreCase("prodotto"))
	{
	  risultato = x*y;
	  simbolo = "x";  
	}
	else if (operazione.equalsIgnoreCase("divisione"))
	{
	  risultato = x/y;
	  simbolo = "/";  
	}
 	if (simbolo != "")
	{
	  return x + " " + simbolo + " " + y + " = " + risultato;
	}
	else
	{
	  return "ERRORE";
	}
    } 
}
