package org.calculator; 
public interface Calcolatrice 
{ 
  String calcola(String operazione, Double x, Double y); 
}
