import Calcolatrice_pkg.*;

public class client 
{
      public static void main(String args[] ) throws Exception
      {
        CalcolatriceService service = new CalcolatriceServiceLocator();
        Calcolatrice handler = service.getCalcolatrice();

	String operazione = args[0];
	Double x = Double.parseDouble(args[1]);
	Double y = Double.parseDouble(args[2]);

	System.out.println(handler.calcola(operazione, x,y));

      }
}
